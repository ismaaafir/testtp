package com.example.tp4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.service.controls.templates.StatelessTemplate
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var charge=findViewById<TextView>(R.id.chargement)
        var prog=findViewById<ProgressBar>(R.id.progress)
        var lay=findViewById<LinearLayout>(R.id.Mes3but)

        object: CountDownTimer(3000L,30L){
            override fun onTick(mil : Long) {
//Pour chaque pas de 30ms réaliser cela
                charge.text="Chargement : "+(100-mil/30)+" %"
                prog.setProgress((100-mil/30).toInt())

            }
            override fun onFinish() {
//Après 3s réaliser cela
                //lay.visibility= View.VISIBLE
                lay.isVisible=true
            }
        }.start()



    }
}